#!/usr/bin/env python3
"""
HVM Panel - License Client (hardened)
=====================================
Talks to the central License Server and enforces license validity locally.

Security model
--------------
- The License Server signs every response with an Ed25519 *private key*.
- The matching *public key* is **embedded directly in this file** (replaced
  per-deployment with `python license_server.py setup-client <path>`).
- Every successful response is cached locally as the raw signed envelope.
- `is_activated()` does NOT trust any boolean in SQLite. Instead, on EVERY
  call it:
      1. loads the cached envelope blob
      2. verifies its Ed25519 signature against the embedded public key
      3. checks `data.status == "active"`
      4. checks `data.machine_id` matches the local machine_id
      5. checks the envelope timestamp is within the freshness window
  Only if ALL pass is the license considered valid.
- A background thread re-validates every 5 minutes; the freshness window is
  3x that interval, so if the server is unreachable for >15 min the panel
  auto-deactivates and bounces users to /activate-license.
- Tampering vectors that DO NOT work:
    * Flipping `activated` in SQLite              -> ignored (we verify envelope)
    * Replaying an old "active" response          -> blocked by freshness check
    * Pointing to a fake license server           -> signature won't verify
    * Swapping the embedded public key            -> hvm.py cross-fingerprint fails
    * Stubbing license_client.is_activated()      -> @requires_license in hvm.py
                                                     re-verifies independently
    * Deleting license_client.py                  -> hvm.py fails to import
"""

from __future__ import annotations

import os
import sys
import json
import time
import uuid
import base64
import hashlib
import hmac
import secrets
import sqlite3
import logging
import threading
from contextlib import contextmanager
from datetime import datetime, timezone


def _utcnow():
    """Timezone-naive UTC datetime that doesn't emit a deprecation warning."""
    return datetime.now(timezone.utc).replace(tzinfo=None)
from typing import Optional, Tuple, Dict, Any

import requests
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

logger = logging.getLogger(__name__)


# ============================================================================
#  DEPLOYMENT CONFIGURATION
# ----------------------------------------------------------------------------
#  Replace these two constants with YOUR values after you set up the License
#  Server. The easiest way is:
#
#       python license_server/license_server.py setup-client \
#               --target ./license_client.py \
#               --url    https://license.yourdomain.com
#
#  After patching, ship the panel to customers. Customers MUST NOT modify
#  these values (and even if they do, hvm.py's startup cross-check refuses
#  to run when the fingerprint changes).
# ============================================================================

LICENSE_SERVER_URL: str = "https://license.weblabindia.in"

EMBEDDED_PUB_KEY_PEM: str = """-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA6PHkKzbY5PhQ2ZsAQI5AqF0TSiRazRu+fnFX7QUcRV8=
-----END PUBLIC KEY-----
"""

# ============================================================================
#  Tuneables (safe defaults â€” change only if you know what you're doing)
# ============================================================================

# Re-validate against the license server every N seconds.
RECHECK_INTERVAL = int(os.getenv("LICENSE_RECHECK_INTERVAL", 300))  # 5 minutes
# How long a cached envelope is trusted offline. The server can be unreachable
# for at most this long before the panel deactivates. 3x recheck = 15 min.
MAX_ENVELOPE_AGE = int(os.getenv("LICENSE_MAX_ENVELOPE_AGE",
                                 max(RECHECK_INTERVAL * 3, 900)))
# HTTP request timeout.
HTTP_TIMEOUT = int(os.getenv("LICENSE_HTTP_TIMEOUT", 15))
# Consecutive network failures tolerated before deactivating the panel.
NETWORK_GRACE = int(os.getenv("LICENSE_NETWORK_GRACE", 3))
PANEL_VERSION = os.getenv("PANEL_VERSION", "unknown")

# Internal cache: parsed Ed25519 public key.
_PUBLIC_KEY_OBJ: Optional[Ed25519PublicKey] = None
_LOCK = threading.RLock()
_THREAD_STARTED = False
_DB_PATH: Optional[str] = None


# ----------------------------------------------------------------------------
#  Public key loading (embedded in source; env override only for dev setup)
# ----------------------------------------------------------------------------

def _resolve_pub_key_pem() -> str:
    """Return the public key PEM. Embedded wins unless explicitly disabled
    AND a valid override is provided (developer setup only)."""
    pem = EMBEDDED_PUB_KEY_PEM
    if "REPLACE_WITH_YOUR_PUBLIC_KEY_PEM_BLOCK" in pem:
        # Allow env-based override ONLY when the placeholder hasn't been
        # replaced yet (i.e. the panel is still un-provisioned).
        env_pem = (os.getenv("LICENSE_PUBLIC_KEY") or "").strip()
        env_file = (os.getenv("LICENSE_PUBLIC_KEY_FILE") or "").strip()
        if env_pem:
            return env_pem
        if env_file and os.path.isfile(env_file):
            try:
                return open(env_file, "r", encoding="utf-8").read()
            except Exception:
                pass
    return pem


def _load_public_key() -> Optional[Ed25519PublicKey]:
    global _PUBLIC_KEY_OBJ
    if _PUBLIC_KEY_OBJ is not None:
        return _PUBLIC_KEY_OBJ
    pem = _resolve_pub_key_pem()
    if not pem or "REPLACE_WITH_YOUR_PUBLIC_KEY_PEM_BLOCK" in pem:
        logger.error(
            "License public key is not configured. Run "
            "'python license_server.py setup-client' to provision this panel."
        )
        return None
    try:
        key = serialization.load_pem_public_key(pem.encode())
        if not isinstance(key, Ed25519PublicKey):
            logger.error("Configured public key is not Ed25519.")
            return None
        _PUBLIC_KEY_OBJ = key
        return key
    except Exception as e:
        logger.error("Failed to load license public key: %s", e)
        return None


def get_public_key_fingerprint() -> str:
    """SHA-256 hex of the embedded public key PEM (whitespace-normalised).
    Used by hvm.py for the cross-tamper check."""
    pem = _resolve_pub_key_pem()
    normalised = "\n".join(line.strip() for line in pem.splitlines() if line.strip())
    return hashlib.sha256(normalised.encode()).hexdigest()


def get_server_url() -> str:
    # Allow env override of the URL only when the placeholder is still set.
    if LICENSE_SERVER_URL == "https://license.example.com":
        return os.getenv("LICENSE_SERVER_URL",
                         LICENSE_SERVER_URL).rstrip("/")
    return LICENSE_SERVER_URL.rstrip("/")


# ----------------------------------------------------------------------------
#  Local state storage
# ----------------------------------------------------------------------------

def _get_db_path() -> str:
    return _DB_PATH or os.getenv("DATABASE_PATH", "hvm.db")


@contextmanager
def _db():
    conn = sqlite3.connect(_get_db_path(), timeout=15)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def init_license_storage(db_path: Optional[str] = None) -> None:
    """Create state table; called once at panel startup."""
    global _DB_PATH
    if db_path:
        _DB_PATH = db_path
    with _db() as conn:
        c = conn.cursor()
        c.execute("""
        CREATE TABLE IF NOT EXISTS license_state (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            machine_id TEXT,
            status TEXT,
            usage_type TEXT,
            max_activations INTEGER,
            owner TEXT,
            expires_at TEXT,
            last_check_at TEXT,
            last_success_at TEXT,
            last_error TEXT,
            failure_count INTEGER NOT NULL DEFAULT 0,
            activated_at TEXT,
            activated_by TEXT,
            server_url TEXT,
            key_blob TEXT,            -- license key, XOR-obfuscated
            cached_envelope TEXT      -- raw signed envelope (json)
        )""")
        # Migrations for older deployments
        for col, ddl in [
            ("machine_id", "TEXT"),
            ("status", "TEXT"),
            ("usage_type", "TEXT"),
            ("max_activations", "INTEGER"),
            ("owner", "TEXT"),
            ("expires_at", "TEXT"),
            ("last_check_at", "TEXT"),
            ("last_success_at", "TEXT"),
            ("last_error", "TEXT"),
            ("failure_count", "INTEGER NOT NULL DEFAULT 0"),
            ("activated_at", "TEXT"),
            ("activated_by", "TEXT"),
            ("server_url", "TEXT"),
            ("key_blob", "TEXT"),
            ("cached_envelope", "TEXT"),
        ]:
            try:
                c.execute(f"ALTER TABLE license_state ADD COLUMN {col} {ddl}")
            except sqlite3.OperationalError:
                pass
        c.execute("SELECT COUNT(*) FROM license_state")
        if c.fetchone()[0] == 0:
            c.execute("INSERT INTO license_state (id, failure_count) VALUES (1, 0)")
        c.execute("SELECT machine_id FROM license_state WHERE id = 1")
        row = c.fetchone()
        if not row or not row["machine_id"]:
            c.execute("UPDATE license_state SET machine_id = ? WHERE id = 1",
                      (str(uuid.uuid4()),))
        conn.commit()


def _get_state() -> Optional[sqlite3.Row]:
    with _db() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM license_state WHERE id = 1")
        return c.fetchone()


def _update_state(**fields) -> None:
    if not fields:
        return
    cols = ", ".join(f"{k} = ?" for k in fields)
    vals = list(fields.values())
    with _db() as conn:
        conn.execute(f"UPDATE license_state SET {cols} WHERE id = 1", vals)
        conn.commit()


def get_machine_id() -> str:
    s = _get_state()
    if s and s["machine_id"]:
        return s["machine_id"]
    mid = str(uuid.uuid4())
    _update_state(machine_id=mid)
    return mid


# ----------------------------------------------------------------------------
#  Cryptographic verification of a signed envelope
# ----------------------------------------------------------------------------

def verify_signed_response(resp_json: Dict[str, Any]
                           ) -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """Verify a *fresh* signed response returned by the License Server."""
    pub = _load_public_key()
    if pub is None:
        return False, None, "client missing public key"
    try:
        envelope = resp_json["envelope"]
        signature = resp_json["signature"]
        alg = resp_json.get("alg", "ed25519")
    except (KeyError, TypeError):
        return False, None, "malformed response"
    if alg != "ed25519":
        return False, None, f"unsupported algorithm: {alg}"
    canonical = json.dumps(envelope, sort_keys=True,
                           separators=(",", ":")).encode()
    try:
        pub.verify(base64.b64decode(signature), canonical)
    except (InvalidSignature, ValueError, TypeError):
        # Most common cause: the License Server's signing key was regenerated
        # (or the panel was provisioned against a different server). The fix
        # is to re-run `python license_server.py setup-client` so the embedded
        # public key matches the one the server is currently signing with.
        return False, None, (
            "signature verification failed - the license server is signing "
            "with a different key than the one embedded in this panel. "
            "Re-run 'python license_server.py setup-client --target "
            "license_client.py --url <server_url>' to re-provision."
        )
    try:
        ts = int(envelope.get("ts", 0))
    except (TypeError, ValueError):
        return False, None, "invalid envelope timestamp"
    drift = time.time() - ts
    # Fresh responses must be within RESPONSE max-age (set by server, usually 600s)
    if ts <= 0 or drift < -120 or drift > MAX_ENVELOPE_AGE:
        return False, None, f"stale response (age={int(drift)}s)"
    data = envelope.get("data") or {}
    if not isinstance(data, dict):
        return False, None, "invalid envelope data"
    return True, data, "ok"


def _verify_cached_envelope(raw_json: Optional[str],
                            expected_machine_id: str
                            ) -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """Verify a cached envelope loaded from local storage. Same checks plus
    machine_id binding."""
    if not raw_json:
        return False, None, "no cached envelope"
    try:
        payload = json.loads(raw_json)
    except (TypeError, ValueError):
        return False, None, "cached envelope unreadable"
    ok, data, msg = verify_signed_response(payload)
    if not ok:
        return False, None, msg
    if data.get("status") != "active":
        return False, data, f"envelope status: {data.get('status')}"
    env_mid = data.get("machine_id")
    if env_mid and env_mid != expected_machine_id:
        return False, data, "machine_id mismatch"
    return True, data, "ok"


# ----------------------------------------------------------------------------
#  License key storage (XOR-obfuscated, key derived from machine_id)
# ----------------------------------------------------------------------------

def _xor(data: bytes, key: bytes) -> bytes:
    if not key:
        return data
    out = bytearray(len(data))
    for i, b in enumerate(data):
        out[i] = b ^ key[i % len(key)]
    return bytes(out)


def _key_for_machine(machine_id: str, salt: bytes) -> bytes:
    return hashlib.sha256(("license::" + machine_id).encode() + salt).digest()


def _encrypt_key(plain: str, machine_id: str) -> str:
    salt = secrets.token_bytes(16)
    blob = _xor(plain.encode("utf-8"), _key_for_machine(machine_id, salt))
    return base64.b64encode(salt + blob).decode()


def _decrypt_key(blob_b64: Optional[str], machine_id: str) -> Optional[str]:
    if not blob_b64:
        return None
    try:
        raw = base64.b64decode(blob_b64)
        salt, blob = raw[:16], raw[16:]
        return _xor(blob, _key_for_machine(machine_id, salt)).decode("utf-8")
    except Exception:
        return None


# ----------------------------------------------------------------------------
#  Network â€” talking to the license server
# ----------------------------------------------------------------------------

def _build_request(license_key: str) -> Dict[str, Any]:
    return {
        "license_key": license_key,
        "machine_id": get_machine_id(),
        "panel_version": PANEL_VERSION,
        "ts": int(time.time()),
        "nonce": secrets.token_hex(16),
    }


def _post(path: str, payload: Dict[str, Any]
          ) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str], str]:
    """Returns (ok, verified_data, raw_envelope_json, message)."""
    url = get_server_url()
    if not url or url == "https://license.example.com":
        return False, None, None, "LICENSE_SERVER_URL not configured"
    full = url + path
    try:
        resp = requests.post(full, json=payload, timeout=HTTP_TIMEOUT,
                             headers={"User-Agent": f"HVM-Panel/{PANEL_VERSION}"})
    except requests.RequestException as e:
        return False, None, None, f"network error: {e.__class__.__name__}"
    if resp.status_code >= 500:
        return False, None, None, f"server error {resp.status_code}"
    try:
        body = resp.json()
    except ValueError:
        return False, None, None, "invalid JSON response"
    ok, data, msg = verify_signed_response(body)
    if not ok:
        return False, None, None, msg
    return True, data, json.dumps(body, separators=(",", ":")), msg


def activate_with_server(license_key: str,
                         activated_by: str = "web") -> Tuple[bool, str]:
    license_key = (license_key or "").strip()
    if not license_key:
        return False, "License key is required."
    body = _build_request(license_key)
    ok, data, envelope_raw, err = _post("/api/v1/activate", body)
    now_iso = _utcnow().isoformat()
    if not ok:
        logger.warning("activate failed: %s", err)
        _update_state(last_check_at=now_iso, last_error=err[:255])
        return False, f"Could not validate license ({err})."
    status = data.get("status")
    if status != "active":
        _update_state(
            status=status, last_check_at=now_iso,
            last_error=(data.get("message") or status or "invalid")[:255],
            cached_envelope=None,
        )
        return False, data.get("message") or status or "invalid"
    # Success â€” persist obfuscated key + cached signed envelope
    mid = get_machine_id()
    _update_state(
        status="active",
        usage_type=data.get("usage_type"),
        max_activations=data.get("max_activations"),
        owner=data.get("owner"),
        expires_at=data.get("expires_at"),
        last_check_at=now_iso,
        last_success_at=now_iso,
        last_error=None,
        failure_count=0,
        activated_at=now_iso,
        activated_by=activated_by,
        server_url=get_server_url(),
        key_blob=_encrypt_key(license_key, mid),
        cached_envelope=envelope_raw,
    )
    logger.info("License activated successfully (cryptographically verified)")
    return True, "License activated successfully!"


def revalidate_with_server() -> Tuple[bool, str, Dict[str, Any]]:
    s = _get_state()
    if not s:
        return False, "no state", {}
    key = _decrypt_key(s["key_blob"], s["machine_id"])
    if not key:
        return False, "no stored key", {}
    body = _build_request(key)
    ok, data, envelope_raw, err = _post("/api/v1/validate", body)
    now_iso = _utcnow().isoformat()
    if not ok:
        fc = (s["failure_count"] or 0) + 1
        _update_state(last_check_at=now_iso,
                      last_error=err[:255], failure_count=fc)
        if fc >= NETWORK_GRACE:
            # Don't blow away the envelope â€” let it expire naturally via the
            # freshness check in is_activated().
            logger.error("License server unreachable %d times; envelope "
                         "will expire naturally.", fc)
        return False, err, {}
    status = data.get("status")
    if status == "active":
        _update_state(
            status="active",
            usage_type=data.get("usage_type"),
            max_activations=data.get("max_activations"),
            owner=data.get("owner"),
            expires_at=data.get("expires_at"),
            last_check_at=now_iso,
            last_success_at=now_iso,
            last_error=None,
            failure_count=0,
            cached_envelope=envelope_raw,
        )
        return True, "active", data
    # Server actively said NO â€” deactivate immediately
    msg = data.get("message") or status or "invalid"
    _update_state(status=status, last_check_at=now_iso,
                  last_error=msg[:255], cached_envelope=None)
    logger.warning("License deactivated by server: %s", msg)
    return False, msg, data


# ----------------------------------------------------------------------------
#  Authoritative activation check (the ground truth)
# ----------------------------------------------------------------------------

def is_activated() -> bool:
    """Returns True iff the cached signed envelope is currently valid.
    Does NOT consult any boolean flag â€” only cryptography."""
    s = _get_state()
    if not s:
        return False
    ok, _data, _msg = _verify_cached_envelope(s["cached_envelope"],
                                              s["machine_id"])
    return ok


def get_signed_envelope() -> Optional[Dict[str, Any]]:
    """Return the cached envelope's verified data dict, or None."""
    s = _get_state()
    if not s:
        return None
    ok, data, _ = _verify_cached_envelope(s["cached_envelope"], s["machine_id"])
    return data if ok else None


def get_status_info() -> Dict[str, Any]:
    s = _get_state()
    if not s:
        return {"activated": False}
    info = {k: s[k] for k in s.keys()}
    # never leak the encrypted key blob or full envelope
    info.pop("key_blob", None)
    info.pop("cached_envelope", None)
    info["activated"] = is_activated()
    return info


# ----------------------------------------------------------------------------
#  Background revalidation thread
# ----------------------------------------------------------------------------

def _loop():
    logger.info("License revalidation thread started (every %ds, "
                "envelope max-age %ds).", RECHECK_INTERVAL, MAX_ENVELOPE_AGE)
    time.sleep(15)  # let app finish booting
    while True:
        try:
            s = _get_state()
            if s and s["cached_envelope"]:
                try:
                    ok, msg, _ = revalidate_with_server()
                    if ok:
                        logger.debug("license re-validation OK")
                    else:
                        logger.warning("license re-validation: %s", msg)
                except Exception as e:
                    logger.exception("revalidate error: %s", e)
        except Exception as e:
            logger.exception("loop error: %s", e)
        time.sleep(RECHECK_INTERVAL)


def start_background_revalidation():
    global _THREAD_STARTED
    with _LOCK:
        if _THREAD_STARTED:
            return
        t = threading.Thread(target=_loop, name="license-revalidate",
                             daemon=True)
        t.start()
        _THREAD_STARTED = True


# ----------------------------------------------------------------------------
#  Decorator for hvm.py route protection (independent verification)
# ----------------------------------------------------------------------------

def requires_license(fallback=None):
    """Decorator: aborts the wrapped function with a 401/redirect if the
    cached signed envelope is not currently valid.

    `fallback` is a callable taking no args; if provided it's invoked when
    the license is invalid (e.g. return a Flask redirect). Otherwise the
    decorator raises PermissionError, which Flask turns into a 403.
    """
    from functools import wraps

    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not is_activated():
                if callable(fallback):
                    return fallback()
                raise PermissionError("License is not active")
            return fn(*args, **kwargs)
        return wrapper
    return deco


# Backwards-compat wrappers (other code already calls these names)
def activate_with_server_wrapped(license_key: str, activated_by: str = "web"):
    return activate_with_server(license_key, activated_by)


def deactivate_local(reason: str = ""):
    _update_state(cached_envelope=None,
                  last_error=reason[:255] if reason else None,
                  last_check_at=_utcnow().isoformat())


__all__ = [
    "LICENSE_SERVER_URL", "EMBEDDED_PUB_KEY_PEM",
    "RECHECK_INTERVAL", "MAX_ENVELOPE_AGE",
    "init_license_storage", "get_machine_id",
    "is_activated", "get_signed_envelope", "get_status_info",
    "verify_signed_response",
    "activate_with_server", "activate_with_server_wrapped",
    "revalidate_with_server", "deactivate_local",
    "start_background_revalidation",
    "requires_license",
    "get_public_key_fingerprint", "get_server_url",
]
