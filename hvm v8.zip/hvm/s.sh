# 1. Capture the correct hardware ID and time
MACHINE_ID=$(python3 -c 'import uuid; print(uuid.getnode())')
NOW=$(date +"%Y-%m-%d %H:%M:%S")

# 2. Inject the master activation record
sqlite3 hvm.db <<EOF
DELETE FROM license;
INSERT INTO license (
    id, 
    license_key, 
    activated, 
    activated_at, 
    activated_by, 
    machine_id, 
    created_at
) VALUES (
    1, 
    'HVMPANEL-PRO-MASTER-BYPASS', 
    1, 
    '$NOW', 
    'admin', 
    '$MACHINE_ID', 
    '$NOW'
);
EOF

# 3. Verify the data is actually there
echo "---------------------------------------"
echo "VERIFYING DATABASE RECORD:"
sqlite3 hvm.db "SELECT license_key, activated, machine_id FROM license WHERE id=1;"
echo "---------------------------------------"
echo "If you see '1' and your ID above, activation is complete."
