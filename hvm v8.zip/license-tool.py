#!/usr/bin/env python3
"""
HVM License Server Cooker v4.0 - Password Protected Tool
=========================================================================
THIS SCRIPT REQUIRES PASSWORD: *******
=========================================================================
"""

import os
import sys
import json
import base64
import secrets
import subprocess
import argparse
import re
import hashlib
import getpass
from pathlib import Path

# Password hash for "****" (SHA-256)
PASSWORD_HASH = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8"

def check_password():
    """Verify password before allowing script to run"""
    print("\n" + "="*60)
    print("🔒 HVM License Server Cooker")
    print("="*60)
    print("\nThis tool is password protected.")
    print("Password: ******")
    print("-"*40)
    
    password = getpass.getpass("Enter password: ")
    
    if hashlib.sha256(password.encode()).hexdigest() != PASSWORD_HASH:
        print("\n❌ INCORRECT PASSWORD!")
        print("Access denied. Exiting...")
        sys.exit(1)
    
    print("\n✅ Access granted!\n")

# Call password check IMMEDIATELY
check_password()

BANNER = """
███╗   ███╗██╗ ██████╗██╗  ██╗ █████╗ ███████╗██╗     
████╗ ████║██║██╔════╝██║  ██║██╔══██╗██╔════╝██║     
██╔████╔██║██║██║     ███████║███████║█████╗  ██║     
██║╚██╔╝██║██║██║     ██╔══██║██╔══██║██╔══╝  ██║     
██║ ╚═╝ ██║██║╚██████╗██║  ██║██║  ██║███████╗███████╗
╚═╝     ╚═╝╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝
                                                      
"""

print(BANNER)

def find_hvm_panel():
    """Find hvm.py in common locations"""
    possible_paths = [
        "hvm.py",
        "../hvm.py",
        "../../hvm.py",
        "/opt/hvm/hvm.py",
        "./hvm.py",
        os.path.expanduser("~/hvm.py"),
        os.path.expanduser("~/hvm/hvm.py"),
    ]
    for p in possible_paths:
        if os.path.exists(p):
            return os.path.abspath(p)
    
    for root, dirs, files in os.walk('.'):
        if 'hvm.py' in files:
            return os.path.abspath(os.path.join(root, 'hvm.py'))
    return None

def backup_file(filepath):
    """Create a backup before modifying"""
    backup_path = f"{filepath}.backup"
    import shutil
    shutil.copy2(filepath, backup_path)
    print(f"[+] Backup created: {backup_path}")
    return backup_path

def patch_serverless(hvm_path):
    """Patch the panel to skip license checks entirely (no server needed)"""
    print("\n[*] --serverless: Patching to skip all license checks...")
    
    if not os.path.exists(hvm_path):
        print(f"[!] Could not find hvm.py at {hvm_path}")
        return False
    
    backup_file(hvm_path)
    
    with open(hvm_path, 'r') as f:
        content = f.read()
    
    modifications = []
    
    # 1. Patch is_license_activated() to always return True
    pattern1 = r'def is_license_activated\(\):.*?(?=\n\S|$)'
    replacement1 = '''def is_license_activated():
    """PATCHED: Always returns True"""
    return True'''
    if re.search(pattern1, content, re.DOTALL):
        content = re.sub(pattern1, replacement1, content, flags=re.DOTALL)
        modifications.append("Patched is_license_activated() -> always True")
    
    # 2. Patch the before_request license check
    pattern2 = r'@app\.before_request\s+def check_license\(\):.*?(?=\n@|\n\S|$)'
    replacement2 = '''@app.before_request
def check_license():
    """PATCHED: License check bypassed"""
    return None'''
    if re.search(pattern2, content, re.DOTALL):
        content = re.sub(pattern2, replacement2, content, flags=re.DOTALL)
        modifications.append("Patched check_license() -> always bypass")
    
    # 3. Patch requires_license decorator
    pattern3 = r'def requires_license\(.*?\).*?:.*?(?=\n    def|\n@|\n\S|$)'
    replacement3 = '''def requires_license(fallback=None):
    """PATCHED: Decorator that always executes the wrapped function"""
    from functools import wraps
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            return fn(*args, **kwargs)
        return wrapper
    return deco'''
    if re.search(pattern3, content, re.DOTALL):
        content = re.sub(pattern3, replacement3, content, flags=re.DOTALL)
        modifications.append("Patched requires_license decorator -> no check")
    
    # 4. Remove the license import check at startup
    pattern4 = r'try:\n    import license_client as _license_client\nexcept ImportError as _e:.*?sys\.exit\(1\)'
    replacement4 = '''# PATCHED: License module import bypassed
_license_client = None
print("*** LICENSE CHECK DISABLED ***")'''
    content = re.sub(pattern4, replacement4, content, flags=re.DOTALL)
    modifications.append("Bypassed license_client import failure")
    
    # 5. Set EXPECTED_LICENSE_PUBKEY_FP to empty
    pattern5 = r'EXPECTED_LICENSE_PUBKEY_FP = "[a-f0-9]+"'
    content = re.sub(pattern5, 'EXPECTED_LICENSE_PUBKEY_FP = ""', content)
    modifications.append("Cleared expected fingerprint")
    
    with open(hvm_path, 'w') as f:
        f.write(content)
    
    print("\n[+] SERVERLESS MODE ACTIVATED!")
    print("[+] The panel will now run with NO license server")
    for mod in modifications:
        print(f"    • {mod}")
    
    return True

def patch_change_server(hvm_path, new_server_url):
    """Change the license server URL to a different server"""
    print(f"\n[*] --change-server: Changing license server URL to: {new_server_url}")
    
    if not os.path.exists(hvm_path):
        print(f"[!] Could not find hvm.py at {hvm_path}")
        return False
    
    backup_file(hvm_path)
    
    with open(hvm_path, 'r') as f:
        content = f.read()
    
    # Change LICENSE_SERVER_URL
    pattern = r'LICENSE_SERVER_URL: str = "https?://[^"]+"'
    replacement = f'LICENSE_SERVER_URL: str = "{new_server_url}"'
    content = re.sub(pattern, replacement, content)
    
    # Also change in license_client.py if it exists
    license_client_path = os.path.join(os.path.dirname(hvm_path), 'license_client.py')
    if os.path.exists(license_client_path):
        with open(license_client_path, 'r') as f:
            lc_content = f.read()
        lc_content = re.sub(r'LICENSE_SERVER_URL: str = "https?://[^"]+"', 
                            f'LICENSE_SERVER_URL: str = "{new_server_url}"', 
                            lc_content)
        with open(license_client_path, 'w') as f:
            f.write(lc_content)
        print(f"[+] Also updated license_client.py")
    
    # Clear fingerprint check to avoid mismatches
    content = re.sub(r'EXPECTED_LICENSE_PUBKEY_FP = "[a-f0-9]+"', 
                     'EXPECTED_LICENSE_PUBKEY_FP = ""', 
                     content)
    
    with open(hvm_path, 'w') as f:
        f.write(content)
    
    print(f"[+] License server URL changed to: {new_server_url}")
    print("[+] Expected fingerprint cleared (will accept any key)")
    
    return True

def generate_keys():
    """Generate Ed25519 keypair"""
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives import serialization
    except ImportError:
        print("[!] Installing cryptography module...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "cryptography"])
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives import serialization
    
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    
    pem_private = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    
    pem_public = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    
    return pem_private.decode(), pem_public.decode()

def create_license_server(domain, username, password, flag):
    """Create the license server script"""
    
    private_key_str, public_key_str = generate_keys()
    
    server_script = f'''#!/usr/bin/env python3
"""
HVM License Server - Generated by Cooker
Run this on your server: python3 this_file.py
"""

import os
import json
import sqlite3
import hashlib
import secrets
import base64
import time
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, request, jsonify, render_template_string, session, redirect, url_for

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
except ImportError:
    import subprocess
    import sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "cryptography"])
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization

app = Flask(__name__)
app.secret_key = "{secrets.token_hex(32)}"

# ============================================================================
# Configuration
# ============================================================================
SERVER_DOMAIN = "{domain}"
ADMIN_USERNAME = "{username}"
ADMIN_PASSWORD_HASH = hashlib.sha256("{password}".encode()).hexdigest()
FLAG = "{flag}"

# ============================================================================
# Database Setup
# ============================================================================
DB_PATH = "licenses.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS licenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        license_key TEXT UNIQUE NOT NULL,
        machine_id TEXT,
        status TEXT DEFAULT 'active',
        owner TEXT,
        usage_type TEXT DEFAULT 'pro',
        max_activations INTEGER DEFAULT 999,
        expires_at TEXT,
        created_at TEXT,
        activated_at TEXT,
        last_seen TEXT,
        notes TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS activity_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        action TEXT,
        license_key TEXT,
        machine_id TEXT,
        ip_address TEXT,
        details TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )''')
    
    c.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", ("maintenance_mode", "0"))
    c.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", ("response_ttl", "600"))
    
    # Create a demo license
    demo_key = f"HVM-DEMO-{{secrets.token_hex(8).upper()}}"
    c.execute('''INSERT OR IGNORE INTO licenses 
                 (license_key, owner, usage_type, status, expires_at, created_at)
                 VALUES (?, ?, ?, ?, ?, ?)''',
              (demo_key, "Demo User", "pro", "active", 
               (datetime.now() + timedelta(days=365)).isoformat(), 
               datetime.now().isoformat()))
    
    conn.commit()
    conn.close()
    return demo_key

# ============================================================================
# Private Key
# ============================================================================
PRIVATE_KEY_PEM = """{private_key_str}"""

def get_private_key():
    return serialization.load_pem_private_key(PRIVATE_KEY_PEM.encode(), password=None)

def sign_response(envelope):
    canonical = json.dumps(envelope, sort_keys=True, separators=(",", ":")).encode()
    signature = get_private_key().sign(canonical)
    return {{
        "envelope": envelope,
        "signature": base64.b64encode(signature).decode(),
        "alg": "ed25519"
    }}

def log_activity(action, license_key, machine_id, details=None):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''INSERT INTO activity_logs 
                 (timestamp, action, license_key, machine_id, details)
                 VALUES (?, ?, ?, ?, ?)''',
              (datetime.now().isoformat(), action, license_key, machine_id, 
               json.dumps(details) if details else None))
    conn.commit()
    conn.close()

# ============================================================================
# API Endpoints
# ============================================================================

@app.route('/api/v1/activate', methods=['POST'])
def activate():
    data = request.get_json()
    license_key = data.get('license_key', '').strip()
    machine_id = data.get('machine_id', '')
    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    c.execute("SELECT * FROM licenses WHERE license_key = ?", (license_key,))
    license_row = c.fetchone()
    
    if not license_row:
        # Auto-create license for ANY key
        expires_at = (datetime.now() + timedelta(days=365*10)).isoformat()
        c.execute('''INSERT INTO licenses 
                     (license_key, machine_id, status, owner, usage_type, 
                      max_activations, expires_at, created_at, activated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                  (license_key, machine_id, 'active', 'Auto User', 'pro',
                   999, expires_at, datetime.now().isoformat(), datetime.now().isoformat()))
        conn.commit()
        license_row = c.execute("SELECT * FROM licenses WHERE license_key = ?", (license_key,)).fetchone()
    
    if license_row['status'] != 'active':
        envelope = {{"data": {{"status": "inactive", "message": f"License is {{license_row['status']}}"}}, "ts": int(time.time())}}
        return jsonify(sign_response(envelope))
    
    c.execute('UPDATE licenses SET last_seen = ?, machine_id = ? WHERE id = ?',
              (datetime.now().isoformat(), machine_id, license_row['id']))
    conn.commit()
    
    envelope = {{
        "data": {{
            "status": "active",
            "machine_id": machine_id,
            "usage_type": license_row['usage_type'],
            "max_activations": license_row['max_activations'],
            "owner": license_row['owner'],
            "expires_at": license_row['expires_at']
        }},
        "ts": int(time.time())
    }}
    
    log_activity('activate', license_key, machine_id, {{'status': 'active'}})
    conn.close()
    return jsonify(sign_response(envelope))

@app.route('/api/v1/validate', methods=['POST'])
def validate():
    data = request.get_json()
    license_key = data.get('license_key', '').strip()
    machine_id = data.get('machine_id', '')
    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    c.execute("SELECT * FROM licenses WHERE license_key = ?", (license_key,))
    license_row = c.fetchone()
    
    if not license_row or license_row['status'] != 'active':
        envelope = {{"data": {{"status": "invalid", "message": "License not found"}}, "ts": int(time.time())}}
        return jsonify(sign_response(envelope))
    
    c.execute('UPDATE licenses SET last_seen = ? WHERE id = ?',
              (datetime.now().isoformat(), license_row['id']))
    conn.commit()
    
    envelope = {{
        "data": {{
            "status": "active",
            "machine_id": machine_id,
            "usage_type": license_row['usage_type'],
            "max_activations": license_row['max_activations'],
            "owner": license_row['owner'],
            "expires_at": license_row['expires_at']
        }},
        "ts": int(time.time())
    }}
    
    conn.close()
    return jsonify(sign_response(envelope))

# ============================================================================
# Admin Panel
# ============================================================================

ADMIN_DASHBOARD = '''
<!DOCTYPE html>
<html>
<head>
    <title>HVM License Server Admin</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0a0e27; color: #e0e0e0; padding: 20px; }}
        .container {{ max-width: 1400px; margin: 0 auto; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; border-radius: 10px; margin-bottom: 20px; }}
        .flag {{ background: #ffd700; color: #000; padding: 10px 20px; border-radius: 5px; font-family: monospace; font-weight: bold; display: inline-block; margin-top: 10px; }}
        .card {{ background: #1a1f3a; border-radius: 10px; padding: 20px; margin-bottom: 20px; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #2a2f4a; }}
        .navbar a {{ color: #667eea; text-decoration: none; padding: 8px 16px; background: #1a1f3a; border-radius: 5px; display: inline-block; margin-right: 10px; }}
        .status-active {{ color: #48bb78; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔐 HVM License Server</h1>
            <div class="flag">🏆 FLAG: {flag}</div>
        </div>
        <div class="navbar">
            <a href="/admin">Dashboard</a>
            <a href="/admin/licenses">Licenses</a>
            <a href="/admin/logs">Logs</a>
            <a href="/admin/logout">Logout</a>
        </div>
        <div class="card">
            <h2>📊 Statistics</h2>
            <table>
                <tr><th>Total Licenses</th><td>{total}</td></tr>
                <tr><th>Active Licenses</th><td>{active}</td></tr>
                <tr><th>Server URL</th><td>http://{domain}:5001</td></tr>
            </table>
        </div>
    </div>
</body>
</html>
'''

@app.route('/')
def index():
    return redirect(url_for('admin_dashboard'))

@app.route('/admin')
def admin_dashboard():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    total = c.execute("SELECT COUNT(*) FROM licenses").fetchone()[0]
    active = c.execute("SELECT COUNT(*) FROM licenses WHERE status = 'active'").fetchone()[0]
    conn.close()
    return render_template_string(ADMIN_DASHBOARD, flag=FLAG, domain=SERVER_DOMAIN, total=total, active=active)

@app.route('/admin/licenses')
def admin_licenses():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    licenses = c.execute("SELECT * FROM licenses ORDER BY created_at DESC").fetchall()
    conn.close()
    rows = ""
    for lic in licenses:
        rows += f"<tr><td><code>{lic['license_key'][:20]}...</code></td><td>{lic['owner'] or '-'}</td><td class='status-active'>{lic['status']}</td><td>{lic['expires_at'][:10] if lic['expires_at'] else 'never'}</td></tr>"
    return f'''
    <html><body style="background:#0a0e27;color:#e0e0e0;padding:20px">
        <h1>Licenses</h1>
        <a href="/admin">← Back</a>
        <table border="1" cellpadding="10"><tr><th>Key</th><th>Owner</th><th>Status</th><th>Expires</th></tr>{rows}</table>
    </body></html>
    '''

@app.route('/admin/logs')
def admin_logs():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    logs = c.execute("SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 100").fetchall()
    conn.close()
    rows = ""
    for log in logs:
        rows += f"<tr><td>{log['timestamp'][:19]}</td><td>{log['action']}</td><td>{log['license_key'][:16]}...</td><td>{log['machine_id'][:16] if log['machine_id'] else '-'}</td></tr>"
    return f'''
    <html><body style="background:#0a0e27;color:#e0e0e0;padding:20px">
        <h1>Activity Logs</h1>
        <a href="/admin">← Back</a>
        <table border="1" cellpadding="10"><tr><th>Time</th><th>Action</th><th>License</th><th>Machine ID</th></tr>{rows}</table>
    </body></html>
    '''

@app.route('/admin/logout')
def admin_logout():
    return redirect('/')

if __name__ == '__main__':
    demo_key = init_db()
    print(f"""
╔══════════════════════════════════════════════════════════════════════════╗
║                    HVM License Server Started!                           ║
╠══════════════════════════════════════════════════════════════════════════╣
║  HTTP URL:      http://{domain}:5001
║  Admin Panel:   http://{domain}:5001/admin
║  Admin Creds:   {username} / {password}
║  Flag:          {flag}
║  Demo License:  {demo_key}
║                                                                          ║
║  ⚡ ANY license key will work - auto-creation enabled!                   ║
║  🌐 Use Cloudflare Tunnel: cloudflared tunnel --url http://localhost:5001║
╚══════════════════════════════════════════════════════════════════════════╝
    """)
    app.run(host="0.0.0.0", port=5001, debug=False, threaded=True)
'''
    
    return server_script, public_key_str

def mode_with_server():
    """Mode --with-server: Run license server"""
    print("\n" + "="*60)
    print("MODE: --with-server (Run Your Own License Server)")
    print("="*60)
    
    domain = input("\n[?] Your domain or local IP (e.g., localhost or 192.168.1.100): ").strip() or "localhost"
    admin_user = input("[?] Admin username (default admin): ").strip() or "admin"
    admin_pass = input("[?] Admin password (default admin123): ").strip() or "admin123"
    flag = input("[?] Challenge flag (press enter for random): ").strip()
    if not flag:
        flag = f"HVM_CRACKED_{{secrets.token_hex(16)}}"
    
    hvm_path = input(f"[?] Path to hvm.py (default: {find_hvm_panel() or 'hvm.py'}): ").strip() or find_hvm_panel() or "hvm.py"
    
    print("\n[*] Generating license server...")
    server_script, public_key = create_license_server(domain, admin_user, admin_pass, flag)
    
    server_path = "hvm_license_server.py"
    with open(server_path, "w") as f:
        f.write(server_script)
    print(f"[+] License server saved to: {server_path}")
    
    # Patch the panel
    if os.path.exists(hvm_path):
        backup_file(hvm_path)
        with open(hvm_path, 'r') as f:
            content = f.read()
        
        # Replace public key
        content = re.sub(r'EMBEDDED_PUB_KEY_PEM: str = """.*?"""', 
                        f'EMBEDDED_PUB_KEY_PEM: str = """{public_key}"""', 
                        content, flags=re.DOTALL)
        
        # Update server URL
        server_url = f"http://{domain}:5001"
        content = re.sub(r'LICENSE_SERVER_URL: str = "https?://[^"]+"',
                        f'LICENSE_SERVER_URL: str = "{server_url}"',
                        content)
        
        # Clear fingerprint check
        content = re.sub(r'EXPECTED_LICENSE_PUBKEY_FP = "[a-f0-9]+"',
                        'EXPECTED_LICENSE_PUBKEY_FP = ""',
                        content)
        
        # Also patch license_client.py if it exists
        license_client_path = os.path.join(os.path.dirname(hvm_path), 'license_client.py')
        if os.path.exists(license_client_path):
            with open(license_client_path, 'r') as f:
                lc_content = f.read()
            lc_content = re.sub(r'LICENSE_SERVER_URL: str = "https?://[^"]+"',
                                f'LICENSE_SERVER_URL: str = "{server_url}"',
                                lc_content)
            lc_content = re.sub(r'EMBEDDED_PUB_KEY_PEM: str = """.*?"""',
                                f'EMBEDDED_PUB_KEY_PEM: str = """{public_key}"""',
                                lc_content, flags=re.DOTALL)
            with open(license_client_path, 'w') as f:
                f.write(lc_content)
            print(f"[+] Also patched license_client.py")
        
        with open(hvm_path, 'w') as f:
            f.write(content)
        print(f"[+] Patched {hvm_path}")
    else:
        print(f"[!] hvm.py not found at {hvm_path}")
        print(f"[!] Manually replace EMBEDDED_PUB_KEY_PEM with:\n{public_key}")
    
    print(f"\n✅ Server mode complete!")
    print(f"\nTo start the license server:")
    print(f"    python3 {server_path}")
    print(f"\nAdmin panel: http://{domain}:5001/admin")
    print(f"Admin credentials: {admin_user} / {admin_pass}")
    print(f"Flag: {flag}")

def mode_serverless():
    """Mode --serverless: Patch to run without any server"""
    print("\n" + "="*60)
    print("MODE: --serverless (No License Server Required)")
    print("="*60)
    
    hvm_path = input(f"[?] Path to hvm.py (default: {find_hvm_panel() or 'hvm.py'}): ").strip() or find_hvm_panel() or "hvm.py"
    
    if patch_serverless(hvm_path):
        print("\n✅ Serverless mode complete!")
        print("\nThe panel will now run with NO license server.")
        print("All license checks have been bypassed.")
        print("\nTo start the panel:")
        print(f"    python3 {hvm_path}")

def mode_change_server():
    """Mode --change-server: Change license server URL"""
    print("\n" + "="*60)
    print("MODE: --change-server (Change License Server URL)")
    print("="*60)
    
    hvm_path = input(f"[?] Path to hvm.py (default: {find_hvm_panel() or 'hvm.py'}): ").strip() or find_hvm_panel() or "hvm.py"
    new_url = input("[?] New license server URL (e.g., http://your-server:5001): ").strip()
    
    if not new_url:
        print("[!] URL required")
        return
    
    if patch_change_server(hvm_path, new_url):
        print("\n✅ Server URL changed successfully!")
        print(f"\nThe panel will now contact: {new_url}")

def main():
    parser = argparse.ArgumentParser(
        description='HVM License Server Cooker v4.0',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  python3 cooker.py --serverless
  python3 cooker.py --with-server --domain localhost
  python3 cooker.py --change-server --url http://your-server:5001
        '''
    )
    
    parser.add_argument('--serverless', action='store_true',
                        help='Patch panel to run without any license server')
    parser.add_argument('--with-server', action='store_true',
                        help='Generate license server and patch panel')
    parser.add_argument('--change-server', action='store_true',
                        help='Point panel to a different license server')
    
    parser.add_argument('--domain', default='localhost',
                        help='Domain/IP for server (for --with-server)')
    parser.add_argument('--url', help='New server URL (for --change-server)')
    parser.add_argument('--admin-user', default='admin',
                        help='Admin username (for --with-server)')
    parser.add_argument('--admin-pass', default='admin123',
                        help='Admin password (for --with-server)')
    parser.add_argument('--flag', help='Challenge flag (for --with-server)')
    parser.add_argument('--hvm-path', help='Path to hvm.py')
    
    args = parser.parse_args()
    
    # Override hvm_path if provided
    if args.hvm_path:
        global find_hvm_panel
        find_hvm_panel = lambda: args.hvm_path
    
    if args.serverless:
        mode_serverless()
    elif args.with_server:
        if args.domain:
            # Non-interactive mode
            hvm_path = args.hvm_path or find_hvm_panel() or "hvm.py"
            server_script, public_key = create_license_server(
                args.domain, args.admin_user, args.admin_pass,
                args.flag or f"HVM_CRACKED_{{secrets.token_hex(16)}}"
            )
            server_path = "hvm_license_server.py"
            with open(server_path, "w") as f:
                f.write(server_script)
            print(f"[+] License server saved to: {server_path}")
            
            if os.path.exists(hvm_path):
                backup_file(hvm_path)
                with open(hvm_path, 'r') as f:
                    content = f.read()
                
                content = re.sub(r'EMBEDDED_PUB_KEY_PEM: str = """.*?"""', 
                                f'EMBEDDED_PUB_KEY_PEM: str = """{public_key}"""', 
                                content, flags=re.DOTALL)
                
                server_url = f"http://{args.domain}:5001"
                content = re.sub(r'LICENSE_SERVER_URL: str = "https?://[^"]+"',
                                f'LICENSE_SERVER_URL: str = "{server_url}"',
                                content)
                
                content = re.sub(r'EXPECTED_LICENSE_PUBKEY_FP = "[a-f0-9]+"',
                                'EXPECTED_LICENSE_PUBKEY_FP = ""',
                                content)
                
                with open(hvm_path, 'w') as f:
                    f.write(content)
                print(f"[+] Patched {hvm_path}")
            
            print(f"\n✅ Server ready!")
            print(f"Server URL: http://{args.domain}:5001")
            print(f"Admin: {args.admin_user} / {args.admin_pass}")
        else:
            mode_with_server()
    elif args.change_server:
        if args.url:
            hvm_path = args.hvm_path or find_hvm_panel() or "hvm.py"
            patch_change_server(hvm_path, args.url)
        else:
            mode_change_server()
    else:
        # Interactive menu
        print("\n" + "="*60)
        print("SELECT MODE")
        print("="*60)
        print("1. --with-server    - Run your own license server")
        print("2. --serverless     - Patch panel to run without any server")
        print("3. --change-server  - Point panel to a different server")
        print("4. Exit")
        
        choice = input("\n[?] Choose mode (1-4): ").strip()
        
        if choice == '1':
            mode_with_server()
        elif choice == '2':
            mode_serverless()
        elif choice == '3':
            mode_change_server()
        else:
            print("Exiting...")
            sys.exit(0)

if __name__ == "__main__":
    main()